var uint8_t = 1;
var uint16_t = 2;
var uint32_t = 4;
var int8_t = -1;
var int16_t = -2;
var int32_t = -4;

