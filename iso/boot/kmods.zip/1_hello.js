
message("%s", "Hello World\n");
